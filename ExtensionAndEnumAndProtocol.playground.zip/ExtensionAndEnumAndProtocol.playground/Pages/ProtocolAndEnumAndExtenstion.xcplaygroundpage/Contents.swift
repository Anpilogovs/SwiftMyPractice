

enum VehicleType:Float, Vehicle, FlyableVehicle {
    var weight: Float {
        return self.rawValue
    }
    
    var speed: Float {
         return self.rawValue
    }
    
    case electric
    case nonElectric
}
protocol Vehicle {
    var weight: Float { get }
    var speed: Float { get }
    var type: VehicleType { get }
    var canFly: Bool { get }
    func prepare()
}

protocol FlyableVehicle {
    func getMaxHight() -> Float
}



struct Car: Vehicle {
    var weight: Float
    var speed: Float
    var type: VehicleType
    
    
}
struct ElectricCar: Vehicle {
    var weight: Float
    var speed: Float
    var type: VehicleType
    
    
}

struct AirPlane: Vehicle  {
    
    
    var weight: Float
    var speed: Float
    var type: VehicleType
    
    
}



extension Vehicle {
    
    var canFly: Bool { return false }
    
    func prepare() {
        switch self.type {
        case .electric: return print("Charge")
        case .nonElectric: return print("Refual")
        }
    }
}

extension Vehicle where Self: FlyableVehicle {
    var canFly: Bool { return true }
    var type: VehicleType { return  VehicleType.electric }
    
    func getMaxHight() -> Float {
        switch self.type {
        case .electric: return weight + speed
        case .nonElectric: return weight * speed
        }
    }
}







var car = Car(weight: 1886, speed: 332, type: .electric)
car.canFly
car.prepare()
var airPlane = AirPlane(weight: 2400, speed: 600, type: .nonElectric)
airPlane.type.canFly
import UIKit

var greeting = "Hello, playground"
