//: [Previous](@previous)

import Foundation

enum DaysOfTheWeek: String {
    case Monday = "Mondey"
    case Tuesday
    case Wednesday = "Wednesday"
    case Thursday
    case Friday
    case Saturday
    case Sunday
}

print(DaysOfTheWeek.Monday.rawValue)
print(DaysOfTheWeek.Sunday.rawValue)

func daysOf(weeks: DaysOfTheWeek) -> String {
    
    switch weeks {
    case .Monday: return "The day is heavy"
    case .Tuesday: return "Already better - since Tuesday"
    case .Wednesday: return "Wednesday - middle of the week"
    case .Thursday: return "Weekend is coming soon"
    case .Friday: return "Yap  - Friday"
    case .Saturday: return "Meeting with friends"
    case .Sunday: return "Rest at home"
    }
}

daysOf(weeks: .Monday)
enum Rank: Int {
       case ace = 1
       case two, three, four, five, six, seven, eight, nine, ten
       case jack, queen, king
       func simpleDescription() -> String {
           switch self {
           case .ace:
               return "ace"
           case .jack:
               return "jack"
           case .queen:
               return "queen"
           case .king:
               return "king"
           default:
               return String(self.rawValue)
           }
} }
   let ace = Rank.ace
   let aceRawValue = ace.rawValue
